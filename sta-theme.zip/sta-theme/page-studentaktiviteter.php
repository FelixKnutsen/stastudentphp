<?php
/**
 * Template Name: Studentaktiviteter (Student Activities)
 */

if (!defined('ABSPATH')) {
    exit;
}

if (empty($sta_directory_only) && class_exists('\Elementor\Plugin') && (\Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() || \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID()))) {
    include STA_THEME_PATH . '/page.php';
    return;
}

if (empty($sta_directory_only)) {
    get_header();
}
$is_en = sta_is_en();
$is_nn = sta_is_nn();

// 1. Try querying CPT sta_activity
$activity_query = new WP_Query(array(
    'post_type'      => 'sta_activity',
    'posts_per_page' => -1,
    'post_status'    => 'publish',
    'orderby'        => array('menu_order' => 'ASC', 'title' => 'ASC'),
));

$items = array();

if ($activity_query->have_posts()) {
    while ($activity_query->have_posts()) {
        $activity_query->the_post();
        $post_id = get_the_ID();
        $categories = get_the_terms($post_id, 'sta_activity_category');
        $cat_name = (!empty($categories) && !is_wp_error($categories)) ? sta_term_name_lang($categories[0]) : sta_t('Annet', 'Other', 'Anna');
        $cat_slug = (!empty($categories) && !is_wp_error($categories)) ? $categories[0]->slug : 'annet';

        $items[] = array(
            'id'           => get_post_field('post_name', $post_id),
            'name'         => get_the_title(),
            'category'     => $cat_name,
            'categorySlug' => $cat_slug,
            'imageUrl'     => get_post_meta($post_id, '_sta_image_url', true) ?: (get_the_post_thumbnail_url($post_id, 'medium') ?: ''),
            'email'        => get_post_meta($post_id, '_sta_email', true),
            'website'      => get_post_meta($post_id, '_sta_website', true),
            'facebook'     => get_post_meta($post_id, '_sta_facebook', true),
            'instagram'    => get_post_meta($post_id, '_sta_instagram', true),
            'discord'      => get_post_meta($post_id, '_sta_discord', true),
            'desc'         => sta_lang_meta($post_id, '_sta_desc_no', '_sta_desc'),
            'when'         => sta_lang_meta($post_id, '_sta_meeting_time', '_sta_meeting_time'),
            'where'        => get_post_meta($post_id, '_sta_location', true),
        );
    }
    wp_reset_postdata();
}

// 2. Fallback to bundled JSON data if no CPT entries yet
if (empty($items)) {
    $json_file = sta_get_data_file('activities.json');
    if ($json_file && file_exists($json_file)) {
        $raw = json_decode(file_get_contents($json_file), true);
        if (is_array($raw)) {
            foreach ($raw as $entry) {
                $items[] = array(
                    'id'           => $entry['id'] ?? '',
                    'name'         => $entry['name'] ?? '',
                    'category'     => $is_en ? ($entry['categoryEn'] ?? $entry['category'] ?? '') : ($entry['category'] ?? ''),
                    'categorySlug' => sanitize_title($entry['category'] ?? ''),
                    'imageUrl'     => $entry['imageUrl'] ?? '',
                    'email'        => $entry['email'] ?? '',
                    'website'      => $entry['websiteUrl'] ?? '',
                    'facebook'     => $entry['facebookUrl'] ?? '',
                    'instagram'    => $entry['instagramUrl'] ?? '',
                    'discord'      => $entry['discordUrl'] ?? '',
                    'desc'         => $is_en ? ($entry['descriptionEn'] ?? $entry['description'] ?? '') : ($entry['description'] ?? ''),
                );
            }
        }
    }
}

// Collect unique categories for filter pills
$categories_map = array();
foreach ($items as $item) {
    if (!empty($item['category']) && !empty($item['categorySlug'])) {
        $categories_map[$item['categorySlug']] = $item['category'];
    }
}
?>

<?php if (empty($sta_directory_only)) : ?>
<div class="sta-container" style="padding-top:3.5rem; padding-bottom:5rem;">
    <header class="sta-page-header">
        <span class="sta-badge"><?php echo esc_html(sta_t('Engasjement og fritid', 'Clubs & Leisure', 'Engasjement og fritid')); ?></span>
        <h1 class="sta-hero-title">
            <?php echo esc_html(sta_t('Studentaktiviteter ved UiA', 'Student Activities at UiA', 'Studentaktivitetar ved UiA')); ?>
        </h1>
        <p class="sta-hero-subtitle" style="max-width:800px; margin-left:auto; margin-right:auto;">
            <?php echo esc_html(sta_t('Her finner du en oversikt over godkjente studentaktiviteter og interesseorganisasjoner ved UiA.', 'Here is an overview of approved student activities and interest organizations at UiA.', 'Her finn du ei oversikt over godkjende studentaktivitetar og interesseorganisasjonar ved UiA.')); ?>
        </p>
    </header>
<?php else : ?>
<div class="sta-directory-embed">
<?php endif; ?>

    <!-- Interactive Search and Filter Controls -->
    <div class="sta-directory-controls" style="max-width:56rem; margin:0 auto 2.5rem auto;">
        <div class="sta-search-box" style="max-width:100%;">
            <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            <input type="search" class="sta-directory-search-input" aria-label="<?php echo esc_attr(sta_t('Søk i studentaktiviteter', 'Search student activities', 'Søk i studentaktivitetar')); ?>" placeholder="<?php echo esc_attr(sta_t('Søk etter kor, idrett, teater, forening...', 'Search choirs, sports, theatre, clubs...', 'Søk etter kor, idrett, teater, foreining...')); ?>" style="border-radius:9999px;">
        </div>

        <div class="sta-filters-pills" role="group" aria-label="<?php echo esc_attr(sta_t('Filtrer etter kategori', 'Filter by category', 'Filtrer etter kategori')); ?>" style="padding-top:0.5rem;">
            <button type="button" class="sta-filter-btn is-active" data-filter="all" aria-pressed="true">
                <?php echo esc_html(sta_t('Alle aktiviteter', 'All activities', 'Alle aktivitetar')); ?> (<?php echo count($items); ?>)
            </button>
            <?php foreach ($categories_map as $slug => $label): 
                $count = 0;
                foreach ($items as $it) {
                    if ($it['categorySlug'] === $slug) $count++;
                }
            ?>
                <button type="button" class="sta-filter-btn" data-filter="<?php echo esc_attr($slug); ?>" aria-pressed="false">
                    <?php echo esc_html($label); ?> (<?php echo $count; ?>)
                </button>
            <?php endforeach; ?>
        </div>

        <div class="sta-directory-count" role="status" aria-live="polite" data-unit="<?php echo esc_attr(sta_t('aktiviteter', 'activities', 'aktivitetar')); ?>" style="color:var(--sta-teal-200); font-size:0.85rem; font-weight:600; margin-top:0.25rem;">
            <?php printf(esc_html(sta_t('Viser %d av %d aktiviteter', 'Showing %d of %d activities', 'Viser %d av %d aktivitetar')), count($items), count($items)); ?>
        </div>
    </div>

    <!-- Cards Grid -->
    <div class="sta-directory-grid" data-more="<?php echo esc_attr(sta_t('Les mer', 'Read more', 'Les meir')); ?>" data-less="<?php echo esc_attr(sta_t('Vis mindre', 'Show less', 'Vis mindre')); ?>">
        <?php foreach ($items as $item): ?>
            <div class="sta-directory-card" data-category="<?php echo esc_attr($item['categorySlug']); ?>" style="padding:1.5rem; display:flex; flex-direction:column; justify-content:space-between;">
                <div>
                    <!-- Contained Logo / Image Box (never crops or zooms in on logos) -->
                    <div style="position:relative; height:9.5rem; width:100%; padding:0.85rem; margin-bottom:1rem; border-radius:0.75rem; overflow:hidden; background:rgba(255,255,255,0.07); border:1px solid rgba(158,207,201,0.22); display:flex; align-items:center; justify-content:center;">
                        <?php if (!empty($item['imageUrl'])): ?>
                            <img src="<?php echo esc_url($item['imageUrl']); ?>" alt="<?php echo esc_attr($item['name']); ?>" style="max-width:100%; max-height:100%; width:auto; height:auto; object-fit:contain; border-radius:0.4rem;" loading="lazy">
                        <?php else: ?>
                            <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; font-size:2rem; font-weight:900; color:#fff; background:rgba(255,255,255,0.05); border-radius:0.4rem;">
                                <?php echo esc_html(mb_substr($item['name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div style="margin-bottom:0.5rem;">
                        <span class="sta-badge" style="font-size:0.65rem; padding:0.2rem 0.55rem; background:rgba(239,115,48,0.2); border:1px solid rgba(239,115,48,0.4); color:#ffc39c;">
                            <?php echo esc_html($item['category']); ?>
                        </span>
                    </div>

                    <h2 class="sta-card-title" style="font-size:1.15rem; margin:0 0 0.5rem 0; line-height:1.3;">
                        <?php echo esc_html($item['name']); ?>
                    </h2>

                    <p class="sta-card-desc sta-dir-desc" style="font-size:0.85rem; line-height:1.6;">
                        <?php echo esc_html($item['desc']); ?>
                    </p>

                    <?php if (!empty($item['when']) || !empty($item['where'])): ?>
                        <ul class="sta-dir-meta" style="list-style:none; margin:0.75rem 0 0; padding:0; font-size:0.8rem; line-height:1.5; color:var(--sta-teal-200); display:grid; gap:0.3rem;">
                            <?php if (!empty($item['when'])): ?>
                                <li style="display:flex; gap:0.45rem; align-items:flex-start;"><svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex:none; margin-top:0.2rem;"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg><span><span class="screen-reader-text"><?php echo esc_html(sta_t('Når:', 'When:', 'Når:')); ?> </span><?php echo esc_html($item['when']); ?></span></li>
                            <?php endif; ?>
                            <?php if (!empty($item['where'])): ?>
                                <li style="display:flex; gap:0.45rem; align-items:flex-start;"><svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex:none; margin-top:0.2rem;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg><span><span class="screen-reader-text"><?php echo esc_html(sta_t('Hvor:', 'Where:', 'Kvar:')); ?> </span><?php echo esc_html($item['where']); ?></span></li>
                            <?php endif; ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <div class="sta-dir-socials" style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; row-gap:0.6rem; margin-top:1.25rem; padding-top:1rem; border-top:1px solid rgba(158,207,201,0.2);">
                    <?php if (!empty($item['email']) && is_email($item['email'])): ?>
                        <a class="sta-dir-email" href="mailto:<?php echo esc_attr($item['email']); ?>"><?php echo esc_html($item['email']); ?></a>
                    <?php endif; ?>
                    <div style="display:flex; align-items:center; gap:0.65rem; color:var(--sta-teal-200);">
                        <?php if (!empty($item['facebook'])): ?>
                            <a href="<?php echo esc_url($item['facebook']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($item['name']); ?> Facebook" style="color:var(--sta-teal-200);">
                                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
                            </a>
                        <?php endif; ?>
                        <?php if (!empty($item['instagram'])): ?>
                            <a href="<?php echo esc_url($item['instagram']); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($item['name']); ?> Instagram" style="color:var(--sta-teal-200);">
                                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                            </a>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($item['website'])): ?>
                        <a href="<?php echo esc_url($item['website']); ?>" target="_blank" rel="noopener noreferrer" style="font-size:0.75rem; font-weight:700; color:var(--sta-orange-text); display:inline-flex; align-items:center; gap:0.25rem; text-decoration:none;">
                            <span><?php echo esc_html(sta_t('Nettside', 'Website', 'Nettside')); ?></span>
                            <svg viewBox="0 0 24 24" width="12" height="12" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Empty State -->
    <div class="sta-directory-empty" style="display:none; text-align:center; padding:3rem; background:var(--sta-card-bg); border-radius:var(--sta-radius); margin-top:2rem;">
        <p style="color:var(--sta-teal-200); font-size:1.2rem;"><?php echo esc_html(sta_t('Ingen studentaktiviteter matchet søket ditt.', 'No student activities matched your search.', 'Ingen studentaktivitetar passa til søket ditt.')); ?></p>
    </div>
</div>

<?php
if (empty($sta_directory_only)) {
    get_footer();
}
